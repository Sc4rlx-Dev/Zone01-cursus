package main

func Flags() {
	// fmt.Println("Buuuuugg")
	
}